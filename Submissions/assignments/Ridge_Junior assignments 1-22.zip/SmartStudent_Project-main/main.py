from cli_interface import StudentCLI

if __name__ == "__main__":
    app = StudentCLI()
    app.run()