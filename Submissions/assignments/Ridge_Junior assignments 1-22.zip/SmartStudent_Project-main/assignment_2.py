radius = 3.0
height = 5

# calculating the volume
volume = 3.14159 * radius ** 2 * height

# calculating the surface area
surface_area = 2 * 3.14159 * radius * (radius + height)

print("Volume:", volume, "Surface Area:", surface_area)